# Oficina de CodeIgniter
Códigos necessários para a implementação de um CRUD básico na oficina sobre CodeIgniter no INFDAY 2017

Alterações necessárias no arquivo "autoload":
- Inserir "database" na linha que possui as "libraries"
- Inserir "url" na linha que possui os "helpers"

